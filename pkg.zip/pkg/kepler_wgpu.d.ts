/* tslint:disable */
/* eslint-disable */
export function init(): Promise<void>;
export function get_render_app(vol: CTVolume): Promise<RenderApp>;
export function parse_dcm_files_wasm(files: Array<any>): Promise<DicomRepo>;
export function load_data_from_repo_wasm(image_series_number: string): void;
export class CTVolume {
  private constructor();
  free(): void;
}
export class DicomRepo {
  private constructor();
  free(): void;
  get_all_patients(): string;
  get_patient(patient_id: string): string;
  get_studies_by_patient(patient_id: string): string;
  get_series_by_study(study_id: string): string;
  get_images_by_series(series_id: string): string;
  generate_ct_volume(image_series_id: string): CTVolume;
}
export class GLCanvas {
  private constructor();
  free(): void;
  /**
   * Sends a `UserEvent::$variant` targeted to a specific window index.
   */
  set_slice_speed(index: number, speed: number): void;
  /**
   * Sends a `UserEvent::$variant` targeted to a specific window index.
   */
  set_window_level(index: number, window_level: number): void;
}
export class RenderApp {
  private constructor();
  free(): void;
  get_glcanvas(): GLCanvas;
  run(): Promise<void>;
}

export type InitInput = RequestInfo | URL | Response | BufferSource | WebAssembly.Module;

export interface InitOutput {
  readonly memory: WebAssembly.Memory;
  readonly init: () => void;
  readonly get_render_app: (a: number) => any;
  readonly parse_dcm_files_wasm: (a: any) => any;
  readonly __wbg_ctvolume_free: (a: number, b: number) => void;
  readonly __wbg_dicomrepo_free: (a: number, b: number) => void;
  readonly dicomrepo_get_all_patients: (a: number) => [number, number, number, number];
  readonly dicomrepo_get_patient: (a: number, b: number, c: number) => [number, number, number, number];
  readonly dicomrepo_get_studies_by_patient: (a: number, b: number, c: number) => [number, number, number, number];
  readonly dicomrepo_get_series_by_study: (a: number, b: number, c: number) => [number, number, number, number];
  readonly dicomrepo_get_images_by_series: (a: number, b: number, c: number) => [number, number, number, number];
  readonly dicomrepo_generate_ct_volume: (a: number, b: number, c: number) => [number, number, number];
  readonly __wbg_renderapp_free: (a: number, b: number) => void;
  readonly renderapp_get_glcanvas: (a: number) => number;
  readonly renderapp_run: (a: number) => any;
  readonly __wbg_glcanvas_free: (a: number, b: number) => void;
  readonly glcanvas_set_slice_speed: (a: number, b: number, c: number) => void;
  readonly glcanvas_set_window_level: (a: number, b: number, c: number) => void;
  readonly load_data_from_repo_wasm: (a: number, b: number) => void;
  readonly __externref_table_alloc: () => number;
  readonly __wbindgen_export_1: WebAssembly.Table;
  readonly __wbindgen_exn_store: (a: number) => void;
  readonly __wbindgen_malloc: (a: number, b: number) => number;
  readonly __wbindgen_realloc: (a: number, b: number, c: number, d: number) => number;
  readonly __wbindgen_free: (a: number, b: number, c: number) => void;
  readonly __wbindgen_export_6: WebAssembly.Table;
  readonly __externref_table_dealloc: (a: number) => void;
  readonly closure74_externref_shim: (a: number, b: number, c: any, d: any) => void;
  readonly closure71_externref_shim: (a: number, b: number, c: any) => void;
  readonly closure68_externref_shim_multivalue_shim: (a: number, b: number, c: any) => [number, number, number];
  readonly closure637_externref_shim: (a: number, b: number, c: any) => void;
  readonly _dyn_core__ops__function__FnMut_____Output___R_as_wasm_bindgen__closure__WasmClosure___describe__invoke__h8f68967d84d8121b: (a: number, b: number) => void;
  readonly closure3155_externref_shim: (a: number, b: number, c: any) => void;
  readonly closure3233_externref_shim: (a: number, b: number, c: any) => void;
  readonly closure3254_externref_shim: (a: number, b: number, c: any, d: any) => void;
  readonly __wbindgen_start: () => void;
}

export type SyncInitInput = BufferSource | WebAssembly.Module;
/**
* Instantiates the given `module`, which can either be bytes or
* a precompiled `WebAssembly.Module`.
*
* @param {{ module: SyncInitInput }} module - Passing `SyncInitInput` directly is deprecated.
*
* @returns {InitOutput}
*/
export function initSync(module: { module: SyncInitInput } | SyncInitInput): InitOutput;

/**
* If `module_or_path` is {RequestInfo} or {URL}, makes a request and
* for everything else, calls `WebAssembly.instantiate` directly.
*
* @param {{ module_or_path: InitInput | Promise<InitInput> }} module_or_path - Passing `InitInput` directly is deprecated.
*
* @returns {Promise<InitOutput>}
*/
export default function __wbg_init (module_or_path?: { module_or_path: InitInput | Promise<InitInput> } | InitInput | Promise<InitInput>): Promise<InitOutput>;
